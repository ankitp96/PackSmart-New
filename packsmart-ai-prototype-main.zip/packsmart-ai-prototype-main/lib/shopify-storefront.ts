const apiVersion = '2026-10'

type GraphQLError = { message: string }

type GraphQLResponse<T> = {
  data?: T
  errors?: GraphQLError[]
}

function getStorefrontConfig() {
  const rawDomain =
    process.env.SHOPIFY_STORE_DOMAIN ?? process.env.NEXT_PUBLIC_SHOPIFY_STORE_DOMAIN
  const accessToken =
    process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN ??
    process.env.NEXT_PUBLIC_SHOPIFY_STOREFRONT_ACCESS_TOKEN

  if (!rawDomain || !accessToken) {
    throw new Error('Shopify Storefront credentials are not configured.')
  }

  const domainUrl = new URL(
    rawDomain.startsWith('http') ? rawDomain : `https://${rawDomain}`,
  )

  if (
    domainUrl.protocol !== 'https:' ||
    !/^[a-z0-9.-]+$/i.test(domainUrl.hostname) ||
    domainUrl.port ||
    domainUrl.pathname !== '/'
  ) {
    throw new Error('The configured Shopify domain is invalid.')
  }

  return {
    endpoint: `https://${domainUrl.hostname}/api/${apiVersion}/graphql.json`,
    accessToken,
  }
}

export async function shopifyStorefrontQuery<T>(
  query: string,
  variables: Record<string, unknown>,
): Promise<T> {
  const config = getStorefrontConfig()
  const response = await fetch(config.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Storefront-Access-Token': config.accessToken,
    },
    body: JSON.stringify({ query, variables }),
    cache: 'no-store',
  })

  if (!response.ok) {
    throw new Error(`Shopify Storefront returned HTTP ${response.status}.`)
  }

  const payload = (await response.json()) as GraphQLResponse<T>
  if (payload.errors?.length || !payload.data) {
    throw new Error(
      payload.errors?.map((error) => error.message).join('; ') ||
        'Shopify Storefront returned no data.',
    )
  }

  return payload.data
}
