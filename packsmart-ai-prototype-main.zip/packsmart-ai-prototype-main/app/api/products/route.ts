import { NextRequest } from 'next/server'
import { shopifyStorefrontQuery } from '@/lib/shopify-storefront'
import type { ShopifyProduct } from '@/lib/packsmart-types'

export const dynamic = 'force-dynamic'

const productsQuery = `
  query SearchProducts($first: Int!, $query: String) {
    products(first: $first, query: $query, sortKey: RELEVANCE) {
      edges {
        node {
          id
          title
          handle
          description
          vendor
          availableForSale
          featuredImage {
            url
            altText
          }
          priceRange {
            minVariantPrice {
              amount
              currencyCode
            }
          }
          variants(first: 10) {
            nodes {
              id
              availableForSale
            }
          }
        }
      }
    }
  }
`

type ProductsData = {
  products: {
    edges: Array<{
      node: {
        id: string
        title: string
        handle: string
        description: string
        vendor: string
        availableForSale: boolean
        featuredImage: { url: string; altText: string | null } | null
        priceRange: {
          minVariantPrice: { amount: string; currencyCode: string }
        }
        variants: { nodes: Array<{ id: string; availableForSale: boolean }> }
      }
    }>
  }
}

export async function GET(request: NextRequest) {
  const rawQueries = request.nextUrl.searchParams.getAll('q').slice(0, 4)
  const searchQueries = rawQueries
    .map((rawQuery) =>
      rawQuery
        .normalize('NFKC')
        .replace(/[^\p{L}\p{N}\s-]/gu, ' ')
        .trim()
        .split(/\s+/)
        .filter((term) => term.length > 0)
        .slice(0, 5)
        .join(' '),
    )
    .filter((query, index, queries) => query.length > 0 && queries.indexOf(query) === index)
  const queries = searchQueries.length ? searchQueries : [null]

  try {
    const results = await Promise.all(
      queries.map((query) =>
        shopifyStorefrontQuery<ProductsData>(productsQuery, { first: 8, query }),
      ),
    )

    const productsById = new Map<string, ShopifyProduct>()
    for (const result of results) {
      for (const { node } of result.products.edges) {
        if (productsById.has(node.id)) continue
        const availableVariant = node.variants.nodes.find((variant) => variant.availableForSale)
        productsById.set(node.id, {
          id: node.id,
          title: node.title,
          description: node.description,
          vendor: node.vendor,
          imageUrl: node.featuredImage?.url ?? null,
          imageAlt: node.featuredImage?.altText ?? node.title,
          price: node.priceRange.minVariantPrice.amount,
          currencyCode: node.priceRange.minVariantPrice.currencyCode,
          variantId: availableVariant?.id ?? null,
          availableForSale: node.availableForSale && Boolean(availableVariant),
          handle: node.handle,
        })
      }
    }

    return Response.json({ products: [...productsById.values()], query: searchQueries.join(' · '), source: 'shopify' })
  } catch {
    return Response.json(
      { error: 'The connected Shopify catalog could not be reached.' },
      { status: 502 },
    )
  }
}
