'use client'

import { useState } from 'react'
import useSWR from 'swr'
import {
  ArrowDownRight,
  ArrowRight,
  Backpack,
  CalendarDays,
  Compass,
  Globe2,
  Luggage,
  ShoppingBag,
  Sparkles,
} from 'lucide-react'
import { CheckoutDemo } from '@/components/checkout-demo'
import { PackingChecklist } from '@/components/packing-checklist'
import { ShopifyCatalog } from '@/components/shopify-catalog'
import { TripPlannerForm } from '@/components/trip-planner-form'
import type {
  PackingItem,
  PackingPlan,
  ProductSearchResponse,
  ShopifyProduct,
  TripDetails,
} from '@/lib/packsmart-types'

const initialTrip: TripDetails = {
  destination: 'Kyoto, Japan',
  days: 7,
  budget: 350,
  type: 'Vacation',
  activities: ['City walks', 'Cold weather', 'Dining out'],
  date: '2026-12-06',
}

const starterPlan: PackingPlan = {
  headline: 'A thoughtful first pass.',
  summary: 'A few smart essentials for seven days of winter walks, neighborhood exploring, and slow dinners in Kyoto.',
  items: [
    {
      name: 'Comfortable walking shoes',
      category: 'Clothing',
      priority: 'essential',
      reason: 'Long days on stone streets call for shoes you have already broken in.',
      searchTerm: 'walking shoes',
    },
    {
      name: 'Warm layers you can rewear',
      category: 'Clothing',
      priority: 'essential',
      reason: 'Easy layers work well between cool outdoor walks and warm indoor spaces.',
      searchTerm: 'travel layers',
    },
    {
      name: 'Universal travel adapter',
      category: 'Electronics',
      priority: 'helpful',
      reason: 'Japan uses Type A outlets; check the input label on each device before plugging in.',
      searchTerm: 'travel adapter',
    },
    {
      name: 'Compact umbrella',
      category: 'Weather',
      priority: 'helpful',
      reason: 'A small umbrella is easy to carry if the forecast calls for a shower.',
      searchTerm: 'compact umbrella',
    },
    {
      name: 'A day bag you already love',
      category: 'Bags',
      priority: 'essential',
      reason: 'Bring a comfortable bag from home before considering another purchase.',
      searchTerm: 'travel day bag',
    },
  ],
  tips: [
    'Start with what you already own; buy only what fills a real gap.',
    'Confirm current entry requirements and check the local forecast close to departure.',
  ],
}

async function fetchCatalog(url: string): Promise<ProductSearchResponse> {
  const response = await fetch(url)
  if (!response.ok) throw new Error('Shopify catalog request failed.')
  return response.json() as Promise<ProductSearchResponse>
}

function formatDate(date: string) {
  if (!date) return 'Dates to come'
  const value = new Date(`${date}T12:00:00`)
  if (Number.isNaN(value.getTime())) return 'Dates to come'
  return new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' }).format(value)
}

export function PackSmartApp() {
  const [trip, setTrip] = useState(initialTrip)
  const [plan, setPlan] = useState(starterPlan)
  const [isGenerated, setIsGenerated] = useState(false)
  const [packedItems, setPackedItems] = useState<Set<string>>(new Set())
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationError, setGenerationError] = useState('')
  const [generationHelpUrl, setGenerationHelpUrl] = useState('')
  const [searchTerms, setSearchTerms] = useState<string[]>([])
  const [bagProducts, setBagProducts] = useState<ShopifyProduct[]>([])
  const [checkoutOpen, setCheckoutOpen] = useState(false)

  const catalogParams = new URLSearchParams()
  searchTerms.forEach((term) => catalogParams.append('q', term))
  const catalogKey = `/api/products?${catalogParams.toString()}`
  const {
    data: catalog,
    error: catalogError,
    isLoading: catalogLoading,
    isValidating: catalogValidating,
    mutate: refreshCatalog,
  } = useSWR<ProductSearchResponse>(catalogKey, fetchCatalog, {
    revalidateOnFocus: false,
    keepPreviousData: true,
  })

  async function generatePlan() {
    setIsGenerating(true)
    setGenerationError('')
    setGenerationHelpUrl('')
    try {
      const response = await fetch('/api/packing-list', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(trip),
      })
      const result = (await response.json()) as PackingPlan | { error?: string; setupUrl?: string }
      if (!response.ok || !('items' in result)) {
        setGenerationError('error' in result ? result.error ?? 'Please try again.' : 'Please try again.')
        setGenerationHelpUrl('setupUrl' in result ? result.setupUrl ?? '' : '')
        return
      }
      setPlan(result)
      setPackedItems(new Set())
      setIsGenerated(true)
      const priorityRank = { essential: 0, helpful: 1, optional: 2 }
      const productQueries = [...result.items]
        .sort((first, second) => priorityRank[first.priority] - priorityRank[second.priority])
        .map((item) => item.searchTerm.trim())
        .filter((term, index, terms) => term.length > 0 && terms.indexOf(term) === index)
        .slice(0, 4)
      setSearchTerms(productQueries.length ? productQueries : ['travel'])
      document.getElementById('checklist-title')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    } catch (error) {
      setGenerationError(error instanceof Error ? error.message : 'PackSmart could not finish this list. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  function findProduct(item: PackingItem) {
    setSearchTerms([item.searchTerm])
    document.getElementById('shopping')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  function togglePacked(name: string) {
    setPackedItems((current) => {
      const next = new Set(current)
      if (next.has(name)) next.delete(name)
      else next.add(name)
      return next
    })
  }

  function addProduct(product: ShopifyProduct) {
    setBagProducts((current) =>
      current.some((item) => item.id === product.id) ? current : [...current, product],
    )
  }

  function browseCatalog() {
    setSearchTerms([])
  }

  function openBag() {
    setCheckoutOpen(true)
  }

  return (
    <main className="packsmart-app">
      <header className="site-header">
        <div className="header-inner">
          <a aria-label="PackSmart AI home" className="brand" href="#top">
            <span className="brand-icon"><Backpack aria-hidden="true" /></span>
            <span>packsmart<span className="brand-ai">AI</span></span>
          </a>
          <nav aria-label="Main navigation" className="main-navigation">
            <a className="nav-link is-active" href="#plan">Plan a trip</a>
            <a className="nav-link" href="#shopping">Thoughtful finds</a>
            <a className="nav-link" href="#how-it-works">How it works</a>
          </nav>
          <button aria-label={`Open trip bag${bagProducts.length ? `, ${bagProducts.length} items` : ''}`} className="bag-button" onClick={openBag} type="button">
            <ShoppingBag aria-hidden="true" />
            <span>Trip bag</span>
            {bagProducts.length > 0 && <span className="bag-count">{bagProducts.length}</span>}
          </button>
        </div>
      </header>

      <div className="page-shell" id="top">
        <section className="hero-section" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> YOUR AI TRAVEL COMPANION</div>
            <h1 id="hero-title">Pack for the trip,<br />not the <em>what-ifs.</em></h1>
            <p>Tell us where you&apos;re going. We&apos;ll help you bring what matters — and leave the rest behind.</p>
            <a className="hero-link" href="#plan">Let&apos;s plan your trip <ArrowRight aria-hidden="true" /></a>
            <div className="hero-trust-row">
              <span><Sparkles aria-hidden="true" /> Made around your plans</span>
              <span className="trust-divider" />
              <span>Less guesswork. Less waste.</span>
            </div>
          </div>
          <div className="destination-card">
            <div className="destination-image">
              <img alt="A quiet winter street in Kyoto, Japan" src="/kyoto-travel.png" />
              <div className="image-shade" />
              <div className="photo-tag"><Compass aria-hidden="true" /> THE SLOW WAY, ALWAYS</div>
              <div className="destination-overlay">
                <span className="destination-label"><Globe2 aria-hidden="true" /> YOUR NEXT ADVENTURE</span>
                <strong>{trip.destination || 'Somewhere wonderful'}</strong>
                <span className="destination-meta"><CalendarDays aria-hidden="true" /> {formatDate(trip.date)} <i /> <Luggage aria-hidden="true" /> {trip.days} days</span>
              </div>
            </div>
            <div className="postcard-footer">
              <span>Considered packing starts with a considered plan.</span>
              <ArrowDownRight aria-hidden="true" />
            </div>
          </div>
        </section>

        {generationError && (
          <div className="form-error" role="alert">
            <span>{generationError}</span>
            {generationHelpUrl && <a href={generationHelpUrl} rel="noreferrer" target="_blank">Open AI Gateway billing</a>}
          </div>
        )}

        <div className="planner-layout">
          <TripPlannerForm
            isLoading={isGenerating}
            onSubmit={generatePlan}
            onTripChange={setTrip}
            trip={trip}
          />
          <PackingChecklist
            isGenerated={isGenerated}
            onFindProduct={findProduct}
            onTogglePacked={togglePacked}
            packedItems={packedItems}
            plan={plan}
            trip={trip}
          />
        </div>

        <ShopifyCatalog
          bagIds={new Set(bagProducts.map((product) => product.id))}
          budget={trip.budget}
          error={catalogError}
          isLoading={catalogLoading}
          isValidating={catalogValidating}
          onAdd={addProduct}
          onBrowseAll={browseCatalog}
          onRetry={() => void refreshCatalog()}
          products={catalog?.products}
          query={catalog?.query || ''}
        />

        <section className="how-it-works" id="how-it-works" aria-labelledby="how-title">
          <div>
            <div className="section-kicker"><span>THE IDEA</span> A MORE CONSIDERED WAY TO SHOP</div>
            <h2 id="how-title">Good advice should help you buy <em>less.</em></h2>
          </div>
          <div className="how-steps">
            <article><span className="how-step-icon"><Sparkles aria-hidden="true" /></span><strong>Understand the trip</strong><p>AI shapes a useful checklist around your destination, dates, and plans.</p></article>
            <article><span className="how-step-icon"><ShoppingBag aria-hidden="true" /></span><strong>Find real products</strong><p>Relevant items come from the connected Shopify catalog — not a made-up list.</p></article>
            <article><span className="how-step-icon"><Compass aria-hidden="true" /></span><strong>Choose with confidence</strong><p>See what&apos;s essential, what&apos;s optional, and what you may already own.</p></article>
          </div>
        </section>

        <footer className="site-footer">
          <a aria-label="PackSmart AI home" className="brand footer-brand" href="#top"><span className="brand-icon"><Backpack aria-hidden="true" /></span><span>packsmart<span className="brand-ai">AI</span></span></a>
          <p>Thoughtful packing for wherever life takes you.</p>
          <span className="footer-note">PACK LIGHT. GO FAR.</span>
        </footer>
      </div>

      <CheckoutDemo open={checkoutOpen} onClose={() => setCheckoutOpen(false)} products={bagProducts} />
    </main>
  )
}
