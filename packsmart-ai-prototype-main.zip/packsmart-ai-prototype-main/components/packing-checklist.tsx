'use client'

import { ArrowUpRight, Check, CircleCheck, PackageCheck, Sparkles } from 'lucide-react'
import type { PackingItem, PackingPlan, TripDetails } from '@/lib/packsmart-types'

type PackingChecklistProps = {
  plan: PackingPlan
  trip: TripDetails
  isGenerated: boolean
  packedItems: Set<string>
  onTogglePacked: (name: string) => void
  onFindProduct: (item: PackingItem) => void
}

export function PackingChecklist({
  plan,
  trip,
  isGenerated,
  packedItems,
  onTogglePacked,
  onFindProduct,
}: PackingChecklistProps) {
  const packedCount = packedItems.size
  const completion = plan.items.length ? Math.round((packedCount / plan.items.length) * 100) : 0

  return (
    <section className="checklist-card" aria-labelledby="checklist-title">
      <div className="checklist-heading-row">
        <div>
          <div className="section-kicker"><span>02</span> YOUR PERSONALIZED KIT</div>
          <h2 id="checklist-title">{isGenerated ? plan.headline : 'A thoughtful first pass.'}</h2>
        </div>
        <div className="ai-stamp" aria-label={isGenerated ? 'AI generated' : 'Sample packing plan'}>
          {isGenerated ? <Sparkles aria-hidden="true" /> : <PackageCheck aria-hidden="true" />}
          <span>{isGenerated ? 'MADE FOR YOU' : 'KYOTO STARTER'}</span>
        </div>
      </div>
      <p className="checklist-summary">{isGenerated ? plan.summary : `A practical first pass for ${trip.days} days in ${trip.destination || 'your destination'}. Build your list above to tailor it to the trip.`}</p>

      <div className="packing-progress" aria-label={`${packedCount} of ${plan.items.length} items packed`}>
        <div className="progress-label"><span><CircleCheck aria-hidden="true" /> {packedCount} of {plan.items.length} packed</span><span>{completion}%</span></div>
        <div className="progress-track"><span style={{ width: `${completion}%` }} /></div>
      </div>

      <ul className="packing-items">
        {plan.items.map((item) => {
          const packed = packedItems.has(item.name)
          return (
            <li className={`packing-item${packed ? ' is-packed' : ''}`} key={item.name}>
              <button
                aria-label={`${packed ? 'Unpack' : 'Mark packed'}: ${item.name}`}
                aria-pressed={packed}
                className="pack-toggle"
                onClick={() => onTogglePacked(item.name)}
                type="button"
              >
                {packed && <Check aria-hidden="true" />}
              </button>
              <div className="packing-item-copy">
                <div className="packing-item-title-row">
                  <span className="packing-item-name">{item.name}</span>
                  <span className={`priority-tag priority-${item.priority}`}>{item.priority}</span>
                </div>
                <p>{item.reason}</p>
              </div>
              <button
                aria-label={`I need to buy this: ${item.name}`}
                className="find-item-button"
                onClick={() => onFindProduct(item)}
                type="button"
              >
                I need this <ArrowUpRight aria-hidden="true" />
              </button>
            </li>
          )
        })}
      </ul>

      <div className="trip-tip">
        <span className="tip-icon"><Sparkles aria-hidden="true" /></span>
        <div>
          <strong>Do I actually need this?</strong>
          <p>{plan.tips[0] ?? 'Start with what you already own; buy only what fills a real gap.'}</p>
        </div>
        <span className="tip-check"><Check aria-hidden="true" /></span>
      </div>
    </section>
  )
}
