export type TripType = 'Vacation' | 'Business' | 'Outdoor adventure'

export type TripDetails = {
  destination: string
  days: number
  budget: number
  type: TripType
  activities: string[]
  date: string
}

export type PackingItem = {
  name: string
  category: string
  priority: 'essential' | 'helpful' | 'optional'
  reason: string
  searchTerm: string
}

export type PackingPlan = {
  headline: string
  summary: string
  items: PackingItem[]
  tips: string[]
}

export type ShopifyProduct = {
  id: string
  title: string
  description: string
  vendor: string
  imageUrl: string | null
  imageAlt: string | null
  price: string
  currencyCode: string
  variantId: string | null
  availableForSale: boolean
  handle: string
}

export type ProductSearchResponse = {
  products: ShopifyProduct[]
  query: string
  source: 'shopify'
}
