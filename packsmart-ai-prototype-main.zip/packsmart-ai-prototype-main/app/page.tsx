import { PackSmartApp } from '@/components/packsmart-app'

export default function Page() {
  return <PackSmartApp />
}
