'use client'

import { useEffect, useRef } from 'react'
import { Check, ShieldCheck, X } from 'lucide-react'
import type { ShopifyProduct } from '@/lib/packsmart-types'

type CheckoutDemoProps = {
  products: ShopifyProduct[]
  open: boolean
  onClose: () => void
}

function formatPrice(amount: string, currencyCode: string) {
  const value = Number(amount)
  if (!Number.isFinite(value)) return `${amount} ${currencyCode}`
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode,
    maximumFractionDigits: 2,
  }).format(value)
}

export function CheckoutDemo({ products, open, onClose }: CheckoutDemoProps) {
  const dialogRef = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const dialog = dialogRef.current
    if (!dialog) return
    if (open && !dialog.open) dialog.showModal()
    if (!open && dialog.open) dialog.close()
  }, [open])

  const total = products.reduce((sum, product) => sum + Number(product.price), 0)
  const currencyCode = products[0]?.currencyCode ?? 'USD'

  return (
    <dialog
      aria-labelledby="checkout-title"
      className="checkout-dialog"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
      onClose={() => {
        if (open) onClose()
      }}
      onCancel={(event) => {
        event.preventDefault()
        onClose()
      }}
      ref={dialogRef}
    >
      <section className="checkout-modal">
        <button aria-label="Close checkout demo" className="modal-close" onClick={onClose} type="button"><X aria-hidden="true" /></button>
        <div className="simulated-checkout-label"><span /> SIMULATED CHECKOUT</div>
        <div className="checkout-success-icon"><Check aria-hidden="true" /></div>
        <h2 id="checkout-title">{products.length ? 'Your travel kit is ready.' : 'Your trip bag is empty.'}</h2>
        <p className="checkout-description">{products.length ? 'This is a prototype checkout preview. No order will be placed and no payment details are collected.' : 'Add a live Shopify find to your trip bag to see it here. This prototype does not place orders or collect payment details.'}</p>
        {products.length > 0 && (
          <div className="checkout-items">
            {products.map((product) => (
              <div className="checkout-line" key={product.id}>
                <span>{product.title}</span>
                <strong>{formatPrice(product.price, product.currencyCode)}</strong>
              </div>
            ))}
            <div className="checkout-total"><span>Estimated total</span><strong>{formatPrice(String(total), currencyCode)}</strong></div>
          </div>
        )}
        <div className="ucp-note">
          <ShieldCheck aria-hidden="true" />
          <span>UCP isn&apos;t connected in this prototype. This step is clearly simulated.</span>
        </div>
        <button className="button-primary modal-done" onClick={onClose} type="button">Back to my trip</button>
      </section>
    </dialog>
  )
}
