'use client'

import { CalendarDays, Check, MapPin, Sparkles } from 'lucide-react'
import type { TripDetails, TripType } from '@/lib/packsmart-types'

type TripPlannerFormProps = {
  trip: TripDetails
  onTripChange: (trip: TripDetails) => void
  onSubmit: () => void
  isLoading: boolean
}

const tripTypes: TripType[] = ['Vacation', 'Business', 'Outdoor adventure']
const activityOptions = ['City walks', 'Cold weather', 'Dining out', 'Day trips']

export function TripPlannerForm({
  trip,
  onTripChange,
  onSubmit,
  isLoading,
}: TripPlannerFormProps) {
  function updateTrip(changes: Partial<TripDetails>) {
    onTripChange({ ...trip, ...changes })
  }

  function toggleActivity(activity: string) {
    const activities = trip.activities.includes(activity)
      ? trip.activities.filter((item) => item !== activity)
      : [...trip.activities, activity]
    updateTrip({ activities })
  }

  return (
    <section className="planner-card" id="plan" aria-labelledby="planner-title">
      <div className="section-kicker"><span>01</span> A FEW TRIP DETAILS</div>
      <h2 id="planner-title">Start with the where.</h2>
      <p className="section-intro">We&apos;ll take it from there.</p>

      <form
        className="trip-form"
        onSubmit={(event) => {
          event.preventDefault()
          onSubmit()
        }}
      >
        <label className="field-label" htmlFor="destination">Where are you headed?</label>
        <div className="input-wrap destination-input">
          <MapPin aria-hidden="true" />
          <input
            autoComplete="address-level2"
            id="destination"
            maxLength={80}
            onChange={(event) => updateTrip({ destination: event.target.value })}
            placeholder="City or country"
            required
            value={trip.destination}
          />
          <span className="input-suffix">Destination</span>
        </div>

        <div className="form-pair">
          <div className="field">
            <label className="field-label" htmlFor="trip-date">Leaving around</label>
            <div className="input-wrap compact-input">
              <CalendarDays aria-hidden="true" />
              <input
                id="trip-date"
                onChange={(event) => updateTrip({ date: event.target.value })}
                type="date"
                value={trip.date}
              />
            </div>
          </div>
          <div className="field">
            <label className="field-label" htmlFor="trip-days">Trip length</label>
            <div className="number-wrap">
              <input
                id="trip-days"
                max={90}
                min={1}
                onChange={(event) => updateTrip({ days: Number(event.target.value) })}
                type="number"
                value={trip.days}
              />
              <span>days</span>
            </div>
          </div>
        </div>

        <div className="field budget-field">
          <label className="field-label" htmlFor="trip-budget">Shopping budget</label>
          <div className="number-wrap budget-wrap">
            <span className="currency-sign">$</span>
            <input
              id="trip-budget"
              max={100000}
              min={0}
              onChange={(event) => updateTrip({ budget: Number(event.target.value) })}
              type="number"
              value={trip.budget}
            />
            <span>USD</span>
          </div>
        </div>

        <fieldset className="trip-type-fieldset">
          <legend className="field-label">What kind of trip?</legend>
          <div className="trip-type-options">
            {tripTypes.map((type) => (
              <label className={`trip-type-option${trip.type === type ? ' is-selected' : ''}`} key={type}>
                <input
                  checked={trip.type === type}
                  name="trip-type"
                  onChange={() => updateTrip({ type })}
                  type="radio"
                  value={type}
                />
                <span>{type}</span>
              </label>
            ))}
          </div>
        </fieldset>

        <fieldset className="activities-fieldset">
          <legend className="field-label">What&apos;s on the itinerary?</legend>
          <div className="activity-options">
            {activityOptions.map((activity) => {
              const isSelected = trip.activities.includes(activity)
              return (
                <label className={`activity-option${isSelected ? ' is-selected' : ''}`} key={activity}>
                  <input
                    checked={isSelected}
                    onChange={() => toggleActivity(activity)}
                    type="checkbox"
                  />
                  <span className="activity-check"><Check aria-hidden="true" /></span>
                  {activity}
                </label>
              )
            })}
          </div>
        </fieldset>

        <button className="button-primary generate-button" disabled={isLoading} type="submit">
          {isLoading ? <span className="button-spinner" aria-hidden="true" /> : <Sparkles aria-hidden="true" />}
          {isLoading ? 'Thinking through your trip…' : 'Build my packing list'}
          {!isLoading && <span className="button-arrow" aria-hidden="true">↗</span>}
        </button>
        <p className="privacy-note">Thoughtful suggestions, never a reason to overpack.</p>
      </form>
    </section>
  )
}
