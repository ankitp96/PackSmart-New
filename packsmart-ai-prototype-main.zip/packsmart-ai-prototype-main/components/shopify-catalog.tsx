'use client'

import Image from 'next/image'
import { ArrowUpRight, LoaderCircle, PackageSearch, Plus, ShoppingBag } from 'lucide-react'
import type { ShopifyProduct } from '@/lib/packsmart-types'

export type CatalogState = {
  products?: ShopifyProduct[]
  error?: Error
  isLoading: boolean
  isValidating: boolean
  query: string
  budget: number
  onBrowseAll: () => void
  onRetry: () => void
  onAdd: (product: ShopifyProduct) => void
  bagIds: Set<string>
}

function formatPrice(amount: string, currencyCode: string) {
  const value = Number(amount)
  if (!Number.isFinite(value)) return `${amount} ${currencyCode}`
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode,
    maximumFractionDigits: 2,
  }).format(value)
}

export function ShopifyCatalog({
  products,
  error,
  isLoading,
  isValidating,
  query,
  budget,
  onBrowseAll,
  onRetry,
  onAdd,
  bagIds,
}: CatalogState) {
  const withinBudget = products?.filter((product) => Number(product.price) <= budget) ?? []

  return (
    <section className="catalog-section" id="shopping" aria-labelledby="catalog-title">
      <div className="catalog-heading-row">
        <div>
          <div className="section-kicker"><span>03</span> ONLY WHAT FILLS A GAP</div>
          <h2 id="catalog-title">Useful finds, not more stuff.</h2>
          <p className="section-intro">Matched to your list from the connected Shopify catalog.</p>
        </div>
        <div className="catalog-source"><span className="source-dot" /> SHOPIFY CATALOG</div>
      </div>

      <div className="catalog-context">
        <div className="catalog-search-term">
          <PackageSearch aria-hidden="true" />
          <span>{query ? `Searching for “${query}”` : 'A few finds to get you started'}</span>
          {isValidating && !isLoading && <LoaderCircle className="subtle-loader" aria-label="Refreshing catalog" />}
        </div>
        <span className="budget-note">Under {formatPrice(String(budget), 'USD')} budget</span>
      </div>

      {error ? (
        <div className="catalog-state" role="alert">
          <div className="state-icon"><PackageSearch aria-hidden="true" /></div>
          <h3>Shopify catalog is taking a breather.</h3>
          <p>We couldn&apos;t load live products just now. Your packing list is still here.</p>
          <button className="button-secondary" onClick={onRetry} type="button">Try again</button>
        </div>
      ) : isLoading ? (
        <div className="product-grid" aria-label="Loading Shopify products">
          {[0, 1, 2].map((index) => <div className="product-skeleton" key={index}><span /><div /><div /></div>)}
        </div>
      ) : products?.length ? (
        withinBudget.length ? (
          <div className="product-grid">
            {withinBudget.slice(0, 6).map((product) => {
              const added = bagIds.has(product.id)
              const configuredDomain = process.env.NEXT_PUBLIC_SHOPIFY_STORE_DOMAIN
              const storeDomain = configuredDomain
                ? new URL(configuredDomain.startsWith('http') ? configuredDomain : `https://${configuredDomain}`).hostname
                : null
              const productUrl = storeDomain ? `https://${storeDomain}/products/${product.handle}` : null
              return (
                <article className="product-card" key={product.id}>
                  <div className="product-image-frame">
                    {product.imageUrl ? (
                      <Image alt={product.imageAlt ?? product.title} className="product-image" fill sizes="(max-width: 680px) 88vw, (max-width: 1080px) 42vw, 27vw" src={product.imageUrl} />
                    ) : (
                      <div className="product-image-fallback"><PackageSearch aria-hidden="true" /></div>
                    )}
                    <span className="product-note">{product.availableForSale ? 'In stock' : 'Currently unavailable'}</span>
                  </div>
                  <div className="product-copy">
                    <span className="product-vendor">{product.vendor || 'Shopify find'}</span>
                    <h3>{product.title}</h3>
                    <p>{product.description || 'A practical travel find for your upcoming trip.'}</p>
                    <div className="product-footer">
                      <span className="product-price">{formatPrice(product.price, product.currencyCode)}</span>
                      <button
                        aria-label={added ? `${product.title} added to trip bag` : `Add ${product.title} to trip bag`}
                        className={`add-product-button${added ? ' is-added' : ''}`}
                        disabled={!product.availableForSale || added}
                        onClick={() => onAdd(product)}
                        type="button"
                      >
                        {added ? <ShoppingBag aria-hidden="true" /> : <Plus aria-hidden="true" />}
                        <span>{added ? 'Added' : product.availableForSale ? 'Add to bag' : 'Unavailable'}</span>
                      </button>
                    </div>
                  </div>
                  {productUrl && (
                    <a aria-label={`View ${product.title} in Shopify`} className="product-external-link" href={productUrl} rel="noreferrer" target="_blank">
                      <ArrowUpRight aria-hidden="true" />
                    </a>
                  )}
                </article>
              )
            })}
          </div>
        ) : (
          <div className="catalog-state">
            <div className="state-icon"><ShoppingBag aria-hidden="true" /></div>
            <h3>Nothing to add just to spend.</h3>
            <p>We didn&apos;t find live items under this trip budget. Try the full catalog, or stick with what you already own.</p>
            <button className="button-secondary" onClick={onBrowseAll} type="button">Browse all finds</button>
          </div>
        )
      ) : (
        <div className="catalog-state">
          <div className="state-icon"><PackageSearch aria-hidden="true" /></div>
          <h3>{query ? 'No exact matches. That may be a good thing.' : 'No products are published yet.'}</h3>
          <p>{query ? 'Try a broader search, or skip shopping if your current kit already covers it.' : 'The Shopify connection is working, but its Storefront catalog is empty. Publish products to the Storefront API in Shopify, then refresh to see them here.'}</p>
          {query ? (
            <button className="button-secondary" onClick={onBrowseAll} type="button">Browse all finds</button>
          ) : (
            <button className="button-secondary" onClick={onRetry} type="button">Refresh Shopify catalog</button>
          )}
        </div>
      )}

      <p className="catalog-footnote">Product information comes from your connected Shopify store. Prices and availability may change.</p>
    </section>
  )
}
